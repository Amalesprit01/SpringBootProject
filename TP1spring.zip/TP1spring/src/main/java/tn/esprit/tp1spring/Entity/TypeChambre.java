package tn.esprit.tp1spring.Entity;

public enum TypeChambre {
SIMPLE
,DOUBLE,
    TRIPLE

}
